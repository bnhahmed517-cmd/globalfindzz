// IMPORTANT: Replace these placeholders before publishing.
// WhatsApp: include country code and digits only, e.g. "447700900123" (no +, spaces or brackets).
// WeChat: enter your exact WeChat ID (not your display name).
window.STORE_CONFIG = {
  storeName: "GlobalFindzz",
  currency: "USD",
  whatsappNumber: "8613376445596",
  wechatId: "AHMEDLEBOSS",
  orderIntro: "Hello! I'm interested in this product:"
};
