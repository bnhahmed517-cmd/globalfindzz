// Product catalog for GlobalFindzz.
// Prices below are illustrative USD placeholders: confirm your real prices before publishing.
// Replace the sample photos with product photos you own or are authorized to use.
window.STORE_PRODUCTS = [
  {
    id: "lacoste-monogram",
    name: "Lacoste Monogram Tracksuit",
    category: "Clothing",
    price: 89,
    tag: "FEATURED",
    description: "Lacoste monogram tracksuit (survêtement), not a T-shirt. Ask us for available sizes, colors and availability.",
    image: "https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=900&q=85"
  },
  {
    id: "crocs-classic-clog",
    name: "Crocs Classic Clogs",
    category: "Shoes",
    price: 49,
    tag: "POPULAR",
    description: "Easygoing everyday clogs. Ask about colors, sizes and availability.",
    image: "https://images.unsplash.com/photo-1562273138-f46be4ebdf33?auto=format&fit=crop&w=900&q=85"
  },
  {
    id: "nike-tech-fleece",
    name: "Nike Tech Fleece Set",
    category: "Clothing",
    price: 115,
    tag: "NEW IN",
    description: "Sport-inspired Tech Fleece look. Contact us to confirm styles, sizes and availability.",
    image: "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=900&q=85"
  },
  {
    id: "everyday-sneaker",
    name: "Everyday Court Sneaker",
    category: "Shoes",
    price: 59,
    tag: "STYLE PICK",
    description: "A clean, versatile sneaker for off-duty days.",
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=85"
  },
  {
    id: "crossbody-bag",
    name: "Structured Crossbody Bag",
    category: "Accessories",
    price: 42,
    tag: "",
    description: "A compact everyday bag with a polished finish.",
    image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=900&q=85"
  },
  {
    id: "minimal-watch",
    name: "Minimal Everyday Watch",
    category: "Accessories",
    price: 49,
    tag: "",
    description: "A simple finishing touch for day-to-night looks.",
    image: "https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=900&q=85"
  }
];
